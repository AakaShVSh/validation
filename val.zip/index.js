const express = require("express");
const { body, validationResult } = require("express-validator");
const res = require("express/lib/response");

const mongoose = require("mongoose");
const app = express();
app.use(express.json());

const connect = () => {

    return mongoose.connect("mongodb://127.0.0.1:27017/val");

}

const userSchema = new mongoose.Schema({
    firstname:{type:String,required:true},
    lastname:{type:String,required:true},
    email:{type:String,required:true},
    age:{type:Number,required:true},
    pincode:{type:String,required:true},
    gender:{type:String,required:true,enum:["Male","female","others"],default:"male"},
},
{
    versionKey:false,
    timestamps:true,
}
)

const User = mongoose.model("user",userSchema);

app.get("/user",async (req,res) => {
    try{
       const user = await User.find().lean().exec();
       res.status(201).send({user:user});
    } catch(err){
       res.status(500).send({err:err.message})
    }
})

app.post("/user",

   body("firstname").trim().not().isEmpty().isAlpha().withMessage("please write your firstname"),
   body("lastname").trim().not().isEmpty().isAlpha().withMessage("please write your lastname"),
   body("email").not().isEmpty().isEmail().withMessage("please write a proper email").custom(async (value) => {
       
           let emailun = await User.findOne({email:value});
           if(emailun){
               throw new Error("please write a valid email");
           }
           return true;

   }),
   body("pincode").trim().not().isEmpty().isNumeric().withMessage("please write your pincode").custom(async (value) => {

          if(value.length == 6){
            return true;
          }
          throw new Error("not a valid pincode");

   }),
   body("age").not().isEmpty().isNumeric().withMessage("please write your age").custom(async (value) => {
          
         if(100 >= value && value >= 1){
           return true;
         }
         throw new Error("please enter a valid age");

   }),
   body("gender").not().isEmpty().custom(async (value) => {

        if(value == "Male"|| value == "Female" || value == "Others"){
            return true;
        }
        throw new Error("enter your valid gender");

   }),

   async (req,res) =>{

    try{
        const errors = validationResult(req);
        // console.log({errors});
        if(!errors.isEmpty()){
            return res.status(400).send({errors:errors.array()});
        }

        let user = await User.create(req.body);
        return res.status(201).send({user:user});
    } catch(err){
         return res.status(500).send({err:err.message});
    }
   }
)


app.listen(5000,async function()  {
    try{
        await connect();
        console.log("running on portal 5000");
    } catch(err){
        console.log(err);
    }
});